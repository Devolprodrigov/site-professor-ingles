// Futuras funcionalidades podem ser adicionadas aqui
console.log("Site carregado com sucesso.");
